public class Pessoa{
    private String nome;
    private int cpf;
    private String email.

    public Pessoa(String nome, int cpf, String email){
        setNome(nome);
        setCpf(cpf);
        setEmail(email);
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setCpf(int cpf){
        this.cpf = cpf;
    }

    public void setEmail(String email){
        this.email = email;
    }

    public String getNome(){
        return nome;
    }

    public int getCpf(){
        return cpf;
    }

    public String getEmail(){
        return email;
    }

    public String toString(){
        System.out.println("Nome: <" + nome + "> | CPF: <" + cpf + ">");
    }
}

class Cliente extends Pessoa{
    private String endereco;
    private int pontosFidelidade = 0;
    private int pontos;

    public Cliente(String endereco, String nome, int cpf, String email, int pontos){
        super(nome, cpf, email);
        setEndereco(endereco);
        setPontos(pontos);
    }

    public void setPontos(int pontos){
        this.pontos = pontos;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    public int getPontos(){
        return pontos;
    }

    public String getEndereco(){
        return endereco;
    }

    public int getPontosFidelidade(){
        return pontosFidelidade;
    }

    public void adicionarPontos(int pontos);
}

class ClienteVip extends Cliente{
    private double percentualDesconto;

    public ClienteVip(double percentualDesconto, String endereco, int pontos){
        super(endereco, pontos);
        setPercentualDesconto(percentualDesconto);
    }

    public void setPercentualDesconto(double percentualDesconto){
        this.percentualDesconto = percentualDesconto;
    }

    public double getPercentualDesconto(){
        return percentualDesconto;
    }

    @Override
    super.toString(nome, cpf, email)
    public String toString(){
        System.out.println(" | VIP (10%)");
    }
}

class Funcionario extends Pessoa{
    private int matricula;
    private double salario;

    public Funcionario(int matricula, double salario, String nome, int cpf, String email){
        super(nome, cpf, email);
        setMatricula(matricula);
        setSalario(salario);
    }

    public void setMatricula(int matricula){
        this.matricula = matricula;
    }

    public void setSalario(double salario){
        this.salario = salario;
    }

    public int getMatricula(){
        return matricula;
    }

    public double getSalario(){
        return salario;
    }
}
