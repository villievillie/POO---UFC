public interface Entregavel {
    double calcularFrete(String cep);
    int prazoEntregaDias();
}

public class ProdutoFisico extends Produto implements Entregavel {
    private double pesoKg;

    public ProdutoFisico(String codigo, String nome, double precoBase, int estoque, double pesoKg) {
        super(codigo, nome, precoBase, estoque);
        this.pesoKg = pesoKg;
    }

    public double getPesoKg() {
        return pesoKg;
    }

    public void setPesoKg(double pesoKg) {
        this.pesoKg = pesoKg;
    }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() * 1.10;
    }

    @Override
    public double calcularFrete(String cep) {
        return 15.00 + 2.00 * pesoKg;
    }

    @Override
    public int prazoEntregaDias() {
        // o prazo depende do CEP, mas a interface não passa o CEP neste método
        return 12;
    }
}

public class ProdutoFisico extends Produto implements Entregavel {
    private double pesoKg;
    private String cepDestino = "";

    public ProdutoFisico(String codigo, String nome, double precoBase, int estoque, double pesoKg) {
        super(codigo, nome, precoBase, estoque);
        this.pesoKg = pesoKg;
    }

    public double getPesoKg() { return pesoKg; }
    public void setPesoKg(double pesoKg) { this.pesoKg = pesoKg; }

    public String getCepDestino() { return cepDestino; }
    public void setCepDestino(String cepDestino) { this.cepDestino = cepDestino; }

    @Override
    public double calcularPrecoFinal() {
        return getPrecoBase() * 1.10;
    }

    @Override
    public double calcularFrete(String cep) {
        this.cepDestino = cep;
        return 15.00 + 2.00 * pesoKg;
    }

    @Override
    public int prazoEntregaDias() {
        return cepDestino.startsWith("6") ? 7 : 12;
    }
}
