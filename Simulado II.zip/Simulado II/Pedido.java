public class Pedido {
    private Cliente cliente;
    private CarrinhoDeCompras carrinho;

    public Pedido(Cliente cliente, CarrinhoDeCompras carrinho) {
        this.cliente = cliente;
        this.carrinho = carrinho;
    }

    public Cliente getCliente() { return cliente; }
    public CarrinhoDeCompras getCarrinho() { return carrinho; }

    public void finalizar(Pagamento pagamento) {
        try {
            double subtotal = carrinho.calcularTotal()
                    + carrinho.calcularFreteTotal(cliente.getEndereco());

            if (cliente instanceof ClienteVip) {
                ClienteVip vip = (ClienteVip) cliente;
                subtotal = subtotal - subtotal * vip.getPercentualDesconto();
            }

            pagamento.exibirComprovante(subtotal);

            double valorPago = pagamento.calcularValorFinal(subtotal);
            cliente.adicionarPontos((int) (valorPago / 10));
        } catch (PagamentoRecusadoException e) {
            System.out.println("Pagamento recusado");
        } finally {
            System.out.println("Pedido encerrado");
        }
    }
}
