public class PagamentoCartao implements Pagamento {
    private int parcelas;

    public PagamentoCartao(int parcelas) {
        this.parcelas = parcelas;
    }

    public int getParcelas() {
        return parcelas;
    }

    public void setParcelas(int parcelas) {
        this.parcelas = parcelas;
    }

    @Override
    public double calcularValorFinal(double valor) {
        if (parcelas > 3) {
            return valor * 1.08;
        }
        return valor;
    }

    @Override
    public String getDescricao() {
        return "Cartão em " + parcelas + "x";
    }
}
