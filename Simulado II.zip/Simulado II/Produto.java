public abstract class Produto{
    private int codigo;
    private String nome;
    private double precoBase;
    private int estoque;
    private double precoFinal;

    public Produto(int codigo, String nome, double precoBase, int estoque){
        setCodigo(codigo);
        setNome(nome);
        setPrecoBase(precoBase);
        setEstoque(estoque);
        setPrecoFinal(precoFinal);
    }

    public void setCodigo(int codigo){
        this.codigo = codigo;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public void setPrecoBase(double precoBase){
        this.precoBse = precoBase;
    }

    public void setEstoque(int estoque){
        this.estoque = estoque;
    }

    public void  setPrecoFinal(double precoFinal){
        this.precoFinal = precoFinal;
    }

    public int getCodigo(){
        return codigo;
    }

    public String getNome(){
        return nome;
    }

    public double getPrecoBase(){
        return precoBase;
    }

    public int getEstoque(){
        return estoque;
    }

    public double getPrecoFinal(){
        return precoFinal;
    }

    public abstract double calcularPrecoFinal();

    public String exibirResumo(){
        System.out.println("<" + codigo + "> - <" + nome + ">: R$" + precoFinal);
        calcularprecoFinal(precoFinal);
    }
}

class ProdutoFisico extends Produto{
    private double pesoKg;

    public ProdutoFisico(double pesokg,int codigo, String nome, double precoBase, int estoque){
        super(codigo, nome, precoBase, estoque);
        setPesoKg(pesoKg);
    }

    public void setPesoKg(double pesoKg){
        this.pesoKg = pesoKg;
    }

    public double getPesoKg(){
        return pesoKg;
    }

    public double calcularPrecoFinal(){
        precoFinal = precoBase + (precoBase * 0.1);
    }
}

class ProdutoDigital extends Produto{
    private int tamanhoMb;

    public ProdutoDigital(int tamanhoMb,int codigo, String nome, double precoBase, int estoque){
        super(codigo, nome, precoBase, estoque);
        setTamanhoMb(tamanhoMb);
    }

    public void setTamanhoMb(int tamanhoMb){
        this.tamanhoMb = tamanhoMb;
    }

    public int getTamanhoMb(){
        return tamanhoMb;
    }

    public double calcularPrecoFinal(){
        precoFinal = precoBase - (precoBase*0.5);
    }
}

class Assinatura extends Produto{
    private int meses;

    public Assinatura(int meses,int codigo, String nome, double precoBase, int estoque){
        super(codigo, nome, precoBase, estoque)
        setMeses(meses);
    }

    public void setMeses(int meses){
        this.meses = meses;
    }

    public int getMeses(){
        return meses;
    }

    public double calcularPrecoFinal(){
        if(meses>=6){
            precoFinal = precoBase * meses;
            precoFinal -= precoFinal*0.1;
        }else{precoFinal = precoBase * meses;}
    }
}
