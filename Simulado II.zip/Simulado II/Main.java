public class Main {
    public static void main(String[] args) throws EstoqueInsuficienteException {
        ClienteVip cliente = new ClienteVip("Ana", "111", "ana@mail.com", "60000-000", 0.10);

        Produto teclado = new ProdutoFisico("F01", "Teclado", 100.0, 5, 0.8);
        Produto ebook = new ProdutoDigital("D01", "E-book Java", 50.0, 999, 12);
        Produto streaming = new Assinatura("S01", "Streaming", 20.0, 999, 6);

        CarrinhoDeCompras carrinho = new CarrinhoDeCompras();
        carrinho.adicionar(teclado);
        carrinho.adicionar(ebook);
        carrinho.adicionar(streaming);

        // Tentativa 1: Pix (aprovado)
        Pedido pedido1 = new Pedido(cliente, carrinho);
        pedido1.finalizar(new PagamentoPix());

        // Tentativa 2: Cartão 6x com limite baixo (recusado)
        Pedido pedido2 = new Pedido(cliente, carrinho);
        pedido2.finalizar(new PagamentoCartao(6, 100.0));

        System.out.println("Pontos de fidelidade: " + cliente.getPontosFidelidade());
    }
}
