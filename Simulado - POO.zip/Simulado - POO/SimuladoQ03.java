public class Autor{
    public String nome;
    public String nacionalidade;

    public Autor(String nome, String nacionalidade){
        this.nome = nome;
        this.nacionalidade = nacionalidade;
    }
}

public class Livro{
    private String titulo;
    private double preco;
    private Autor autor;

    public Livro(String titulo, double preco, Autor autor){
        this.titulo = titulo;
        this.preco = preco;
        this.autor = autor;
    }

    public void exibirDetalhes(){
        System.out.println(titulo);
        System.out.println(autor.nome);
        System.out.printf("R$ %.2lf", preco);
    }
}

public class Main{
    public static void main (String args[]){
        Autor autor = new Autor("Niquel", "Japonesa");
        Livro livro = new Livro("Do que vale o dinheiro", 2894655.452626262, autor);
        livro.exibirDetalhes();
    }
}