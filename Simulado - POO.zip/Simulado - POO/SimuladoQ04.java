import java.util.ArrayList;
import java.util.List;

public class GestaoPedidos{
    private List<String> pedidos;

    public GestaoPedidos(){
        this.pedidos = new ArrayList<>();
    }

    public void adicionarPedido(String item){
        pedidos.add(item);
    }

    public String proximoPedido(){
        if(pedidos.isEmpty()){
            return "Fila Vazia";
        }else{
            pedidos.remove(0);
            return pedidos.get(0);
        }
    }
    public int quantidadePendentes(){
        return pedidos.size();
    }

    public void listarPedidos(){
        for(int i = 0; i < pedidos.size(); i++){
            System.out.println(pedidos.get(i));
        }
    }
}

public class Main{
    public static void main(String[] args){
        GestaoPedidos gestao = new GestaoPedidos();

        gestao.adicionarPedido("Macarrão");
        gestao.adicionarPedido("Feijão");
        gestao.adicionarPedido("Arroz");

        System.out.println(gestao.proximoPedido());
        System.out.println(gestao.quantidadePendentes());
    }
}