public class Retangulo{
    private double largura;
    private double altura;

    public Retangulo(){//construtor padrao
        setLargura(1.0);
        setAltura(1.0);
    }

    public Retangulo(double largura, double altura){//construtor
        setLargura(largura);
        setAltura(altura);
    }

    public void setLargura (double largura){//set
        this.largura = largura;
    }

    public void setAltura (double altura){//set
        this.altura = altura;
    }

    public double getLargura(){//get
        return this.largura;
    }

    public double getAltura(){//get
        return this.altura;
    }

    public double calcularArea(){//metodo calcularArea (não precisa de parametros)
        return this.largura * this.altura;
    }

    public boolean isQuadrado(){
        return (this.largura == this.altura)? true:false;
    }
}

public class main{
    public static void main(String args[]){
        Retangulo retangulo = new Retangulo(5.0, 5.0);//instanciar o objeto.
        System.out.println(retangulo.isQuadrado()? "É quadrado" : "Não é quadrado");
        System.out.println(retangulo.calcularArea());
    }
}